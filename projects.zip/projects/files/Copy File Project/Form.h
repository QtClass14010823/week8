#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QGridLayout>

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);

signals:

private slots:
    void onSrcClicked();
    void onDstClicked();
    void onCopyClicked();

private:
    QGridLayout *bLayout;
    QLabel *lblSrc, *lblDst;
    QLineEdit *lnEditSrc, *lnEditDst;
    QPushButton *btnSrcFile, *btnDstFile;
    QPushButton *btnCopy;
};

#endif // FORM_H
