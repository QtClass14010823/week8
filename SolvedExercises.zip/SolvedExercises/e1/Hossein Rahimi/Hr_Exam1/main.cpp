//
// Hossein Rahimi
// Program No:1
//
#include <QApplication>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
void xchange(void );

QLineEdit *edit1_ptr,*edit2_ptr;

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QWidget w;
    w.setFixedSize(250,150);
    QLabel l1("Value1:",&w),l2("Value2:",&w);
    QLineEdit edit1(&w),edit2(&w);
    QPushButton btn1("Exchange",&w),btn2("Exit",&w);
    edit1_ptr=&edit1;
    edit2_ptr=&edit2;
    l1.move(20,20);
    edit1.move(80,20);
    l2.move(20,60);
    edit2.move(80,60);
    btn1.move(20,100);
    btn2.move(120,100);
    w.show();
    QObject::connect(&btn1,&QPushButton::clicked,xchange);
    QObject::connect(&btn2,&QPushButton::clicked,&app, &QApplication::quit);
    return app.exec();
}

void xchange(void ){
    QString str_tmp;
    if(edit1_ptr!=nullptr && edit2_ptr!=nullptr)
    {
      str_tmp = edit1_ptr->text();
      edit1_ptr->setText(edit2_ptr->text());
      edit2_ptr->setText(str_tmp);
    }
}
