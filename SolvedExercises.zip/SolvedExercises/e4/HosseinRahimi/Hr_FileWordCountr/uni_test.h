#include <QObject>
#include <QTest>

class Uni_Test:public QObject
{
    Q_OBJECT
private slots:
    void w_counter_data();
    void w_counter();

};


