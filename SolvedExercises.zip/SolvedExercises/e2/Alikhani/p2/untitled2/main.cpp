#include <QApplication>
#include <QtGui>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QWidget widget;


    QString str1;
    str1= QString::number(argc-1);
    QLabel label1 ("Parameter Count : " + str1,&widget);
    label1.move(20,10);
    label1.show();
    QLabel label2 ("Parameter 1 : ",&widget);
    label2.move(20,50);
    label2.show();
    QLabel label3 ("Parameter 2 : ",&widget);
    label3.move(20,90);
    label3.show();
    QLabel label4 ("Parameter 3 : ",&widget);
    label4.move(20,130);
    label4.show();


    QPushButton btn2 ("Exit",&widget);
    btn2.move(170,180);
    btn2.show();
    QObject::connect(&btn2, &QPushButton::clicked, &a, &QApplication::quit);



    QString s1,s2,s3;
    if(argc>1)
    {
        s1 = argv[1];s2 = argv[2];s3 = argv[3];
    }

    QLineEdit lineEdit1(s1,&widget);
    lineEdit1.setReadOnly(true);
    lineEdit1.move(120,50);
    lineEdit1.show();
    QLineEdit lineEdit2(s2,&widget);
    lineEdit2.setReadOnly(true);
    lineEdit2.move(120,90);
    lineEdit2.show();
    QLineEdit lineEdit3(s3,&widget);
    lineEdit3.setReadOnly(true);
    lineEdit3.move(120,130);
    lineEdit3.show();

    widget.show();
    return a.exec();
}


