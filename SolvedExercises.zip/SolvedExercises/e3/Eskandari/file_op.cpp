#include <QFile>
#include <QDataStream>
#include <QString>
#include "file_op.h"

void addContact(contactInfo in)
{
    QFile contact_file("contact.dat");
    contact_file.open(QIODevice::WriteOnly | QIODevice::Append);
    QDataStream contact_stream(&contact_file);
    if (!in.name.isEmpty())
    {
        contact_stream << in.name<< in.tel;
    }
    contact_file.close();
}

int countContact()
{
    contactInfo temp;
    int counter =0;
    QFile contact_file("contact.dat");
    if (!contact_file.open(QIODeviceBase::ReadOnly))
    {
        return 0;
    }
    QDataStream contact_stream(&contact_file);
    while(!contact_stream.atEnd())
    {
        contact_stream >> temp.name >> temp.tel;
        counter++;
    }
    contact_file.close();
    return counter;
}

contactInfo findContact(QString name)
{
    contactInfo temp;
    QFile contact_file("contact.dat");
    contact_file.open(QIODeviceBase::ReadOnly);
    QDataStream contact_stream(&contact_file);
    if (!name.isEmpty())
    {
        while(!contact_stream.atEnd())
        {
            contact_stream >> temp.name >> temp.tel;
            if (temp.name == name)
            {
                return temp;
            }
        }
    }
    else
    {
        return (contactInfo){.name="", .tel=0};
    }
    contact_file.close();
    return (contactInfo){.name="Not found", .tel=0};
}
