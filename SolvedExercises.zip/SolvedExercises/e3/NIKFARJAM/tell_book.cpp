#include "tell_book.h"
#include<QDebug>

Tell_Book::Tell_Book(QWidget *parent)
    : QMainWindow(parent)
{

   mainWidget=new QWidget(this);
   mainGride = new QGridLayout();
   mainGride->addWidget(gbox1(),0,0);
   mainGride->addWidget(gbox2(),1,0);
   mainGride->addWidget(gbox3(),2,0);
   mainWidget->setLayout(mainGride);
   setCentralWidget(mainWidget);
   connect(btn1,SIGNAL(clicked(bool)),this,SLOT(Add_Func()));
   connect(btn2,SIGNAL(clicked(bool)),this,SLOT(Find_Func()));
}

Tell_Book::~Tell_Book()
{
}

void Tell_Book::Add_Func()
{
    contact_info *mytell=new contact_info;
    msg =new QMessageBox(this);
    if(lnEdt1->text()!=nullptr && lnEdt2->text()!=nullptr)
    {
        strncpy(mytell->name,lnEdt1->text().toStdString().c_str(),sizeof (mytell->name));
        mytell->tell=lnEdt2->text().toInt();
        QFile file("/home/user/Hwork3/phone_book.dat");

         if (!file.open(QIODevice::Append))
         {
             msg->setText("con not open file");
             msg->show();
          }

        QDataStream out(&file);
        out.writeRawData((char *)&mytell,sizeof(mytell));
        counter++;
        lbl5->setText(QString::number(counter));
        file.close();
        msg->setText("add to contacts");
        msg->exec();
        lnEdt1->clear();
        lnEdt2->clear();
    }
    else
    {
      msg->setText("The value is empty!");
      msg->exec();
    }
}

void Tell_Book::Find_Func()
{
     contact_info *mytell=new contact_info;
     QFile file("/home/user/Hwork3/phone_book.dat");
    if (!file.open(QIODevice::ReadOnly))
    {
        msg->setText("con not open file");
        msg->show();
    }
    QDataStream in(&file); 
    in.readRawData((char *)&mytell,sizeof (mytell));
    QString s1=nullptr;
    QString s2=nullptr;

    s1=mytell->name;
    s2=lnEdt3->text();

    if(s1==s2)
    {
        msg->setText(QString(mytell->name)+" "+ QString::number(mytell->tell));
         msg->show();
    }
    else
    {
        msg->setText("Not Found!");
        msg->exec();
    }

    file.close();


}
QGroupBox *Tell_Book::gbox1()
{
    QGroupBox *gboxinfo=new QGroupBox(tr("Info"));
     lbl1=new QLabel("Contacts count :") ;
     lbl5=new QLabel();

     QHBoxLayout  *hbox= new QHBoxLayout;
     hbox->addWidget(lbl1);
     hbox->addWidget(lbl5);
     gboxinfo->setLayout(hbox);
     return gboxinfo;

}

QGroupBox *Tell_Book::gbox2()
{
    QGroupBox *gboxadd=new QGroupBox(tr("Add"));
    lbl2=new QLabel("Name :");
    lbl3=new QLabel("Tell :");
    lnEdt1=new QLineEdit();
    lnEdt2=new QLineEdit();
    btn1=new QPushButton("Add");
    QGridLayout  *grl=new QGridLayout;

    grl->addWidget(lbl2,0,0);
    grl->addWidget(lbl3,1,0);
    grl->addWidget(lnEdt1,0,1);
    grl->addWidget(lnEdt2,1,1);
    grl->addWidget(btn1,1,2);
    gboxadd->setLayout(grl);
    return gboxadd;
}

QGroupBox *Tell_Book::gbox3()
{
    QGroupBox *gboxfind=new QGroupBox(tr("Find"));
    lbl4=new QLabel("Name :");
    lnEdt3=new QLineEdit();
    btn2=new QPushButton("Find");
    QGridLayout  *grl=new QGridLayout;

    grl->addWidget(lbl4,0,0);
    grl->addWidget(lnEdt3,0,1);
    grl->addWidget(btn2,0,2);
    gboxfind->setLayout(grl);
    return gboxfind;
}
